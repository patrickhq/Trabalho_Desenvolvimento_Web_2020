<?php

include_once ("../servico/Bd.php");

$login = $_POST["login"];
$senha = $_POST["senha"];

if (isset($_POST["id"])) {
    $id = $_POST["id"];
    $sql = "update trabalho set login='$login',  senha='$senha' where id='$id' ";
}else {
    $sql = "INSERT INTO `trabalho` (`id`, `login`, `senha`) VALUES (NULL, '$login', '$senha')";
}


$bd = new Bd();
$contador = $bd->exec($sql); // insert, update e delete

echo "<h1><center> Foi incluído/atualizado $contador registro</center> </h1>";

echo "<center><a href='consultaUsuario.php'>Voltar</center> </a>";

?>